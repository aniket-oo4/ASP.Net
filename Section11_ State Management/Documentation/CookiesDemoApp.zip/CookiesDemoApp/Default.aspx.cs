﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            HttpCookie c = Request.Cookies["Username"];
            if (c == null)
                Response.Redirect("Login.aspx");
            Response.Write("Welcome " + c.Value);
        }
    }
    protected void btnSetCookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = new HttpCookie(txtKey.Text, txtValue.Text);
        if (chkPersistance.Checked)
            c.Expires = DateTime.MaxValue;
        if (chkSecured.Checked)
            c.Secure = true;
        else
            c.Secure = false;
        c.Path = Request.ApplicationPath;
        Response.Cookies.Add(c);
    }
    protected void btnGetCookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = Request.Cookies[txtKey.Text];
        if (c == null)
            txtValue.Text = "Not Available";
        else
            txtValue.Text = c.Value;
    }
    protected void btnDestroyCookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = new HttpCookie(txtKey.Text, txtValue.Text);
        c.Expires = DateTime.Now.AddDays(-1);
        c.Path = Request.ApplicationPath;
        Response.Cookies.Add(c);
    }
    protected void btnGetAllCookies_Click(object sender, EventArgs e)
    {
        lblValue.Text = "";
        foreach (string key in Request.Cookies)
        {
            lblValue.Text += key + " = " + Request.Cookies[key].Value + "<br>";
        }
    }
}
