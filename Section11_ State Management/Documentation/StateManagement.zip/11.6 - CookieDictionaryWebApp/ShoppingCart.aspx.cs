﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShoppingCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAddRadioToCart_Click(object sender, EventArgs e)
    {
        AddProductToCart("radio");
    }
    protected void btnAddTVToCart_Click(object sender, EventArgs e)
    {
        AddProductToCart("tv");
    }
    protected void btnAddTelephoneToCart_Click(object sender, EventArgs e)
    {
        AddProductToCart("telephone");
    }
    private void AddProductToCart(string name)
    {
        HttpCookie c = Request.Cookies["shoppingcart"];
        if (c == null)
            c = new HttpCookie("shoppingcart");
        if (c.Values[name] == null)
            c.Values[name] = "1";
        else
            c.Values[name] = (int.Parse(c.Values[name]) + 1).ToString();
        c.Expires = DateTime.Today.AddDays(3);
        c.Path = Request.ApplicationPath;
        Response.Cookies.Add(c);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Checkout.aspx");
    }
    protected void btnRemoveRadio_Click(object sender, EventArgs e)
    {
        RemoveFromCart("radio");
    }
    protected void btnRemoveTV_Click(object sender, EventArgs e)
    {
        RemoveFromCart("tv");
    }
    protected void btnRemoveTelephone_Click(object sender, EventArgs e)
    {
        RemoveFromCart("telephone");
    }
    private void RemoveFromCart(string name)
    {
        HttpCookie c = Request.Cookies["shoppingcart"];
        if (c == null)
            return;
        if (c.Values[name] != null && c.Values[name] != "0")
        {
            c.Values[name] = (int.Parse(c.Values[name]) - 1).ToString();
        }
        c.Expires = DateTime.MaxValue;
        c.Path = Request.ApplicationPath;
        Response.Cookies.Add(c);
    }
}