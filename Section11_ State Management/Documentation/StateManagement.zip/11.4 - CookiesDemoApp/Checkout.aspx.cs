﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Checkout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["radio"] != null)
            lblRadio.Text = Request.Cookies["radio"].Value;
        else
            lblRadio.Text = "0";
        if (Request.Cookies["tv"] != null)
            lblTV.Text = Request.Cookies["tv"].Value;
        else
            lblTV.Text = "0";
        if (Request.Cookies["telephone"] != null)
            lblTelephone.Text = Request.Cookies["telephone"].Value;
        else
            lblTelephone.Text = "0";
    }
}