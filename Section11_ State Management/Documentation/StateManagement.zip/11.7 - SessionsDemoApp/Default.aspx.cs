﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int n = 0;
        if (!Session.IsNewSession)
            n = (int) Session["cnt"];
        n++;
        Session["cnt"] = n;
        lblSessionCounter.Text = n.ToString();

        int m = 0;
        if (Application["cnt"] != null)
            m = (int)Application["cnt"];
        m++;
        Application["cnt"] = m;
        lblApplicationCounter.Text = m.ToString();

        
        if (Session["username"] == null)
        {
            lblLoginStatus.Text = "Please login:";
            lnkLogin.Text = "Login";
        }
        else
        {
            lblLoginStatus.Text = "Welcome " + Session["username"].ToString();
            lnkLogin.Text = "Logout";
        }
        string url = "http://" + Request.Url.Host + Response.ApplyAppPathModifier("/Login.aspx");
        Response.Write(url);
    }
    protected void lnkLogin_Click(object sender, EventArgs e)
    {
        if (lnkLogin.Text == "Login")
            Response.Redirect("Login.aspx");
        else
        {
            Session.Remove("username");
            Response.Redirect(Request.Path);
        }
    }
}