﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MyData
/// </summary>
public static class MyData
{
    public static string Data;
}