﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Page1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(Server.HtmlEncode("<b>Hello</b>"));
    }
    protected void btnRedirect_Click(object sender, EventArgs e)
    {
        string demo = txtDemo.Text;
        Response.Redirect("Page2.aspx?demo=" + Server.UrlEncode(demo));
    }
    protected void btnTransfer_Click(object sender, EventArgs e)
    {
        Context.Items.Add("demo", txtDemo.Text);
        Server.Transfer("Page2.aspx");
    }
    public string DemoText
    {
        get
        {
            return txtDemo.Text;
        }
    }
}
