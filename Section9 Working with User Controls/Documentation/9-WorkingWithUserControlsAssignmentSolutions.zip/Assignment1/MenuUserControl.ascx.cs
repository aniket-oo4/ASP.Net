﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MenuUserControl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    public string Backgroundcolor
    {
        get;
        set;
    }
    public string InvalidMessage
    {
        get;
        set;
    }
    public string cfNamelabel
    {
        get
        {
            return txtcfName.Text;
        }
        set
        {
            txtcfName.Text = value;
        }
    }
    public string cmNamelable
    {
        get
        {
            return txtcmName.Text;
        }
        set
        {
            txtcmName.Text = value;
        }
    }
    public string clNamelabel
    {
        get
        {
            return txtclName.Text;
        }
        set
        {
            txtclName.Text = value;
        }
    }
    public string ffNamelabel
    {
        get
        {
            return txtffName.Text;
        }
        set
        {
            txtffName.Text = value;
        }
    }
    public string fmNamelabel
    {
        get
        {
            return txtffName.Text;
        }
        set
        {
            txtffName.Text = value;
        }
    }
    public string flNamelabel
    {
        get
        {
            return txtflName.Text;
        }
        set
        {
            txtflName.Text = value;
        }
    }
    public string mfNamelabel
    {
        get
        {
            return txtmfName.Text;
        }
        set
        {
            txtmfName.Text = value;
        }
    }
    public string mmNamelabel
    {
        get
        {
            return txtmmName.Text;
        }
        set
        {
            txtmmName.Text = value;
        }
    }
    public string mlNamelable
    {
        get
        {
            return txtmlName.Text;
        }
        set
        {
            txtmlName.Text = value;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string cf=txtcfName.Text;
        string cm=txtcmName.Text;
        string cl=txtclName.Text;
        string ff=txtffName.Text;
        string fm=txtfmName.Text;
        string fl=txtflName.Text;
        string mf=txtmfName.Text;
        string mm=txtmmName.Text;
        string ml=txtmlName.Text;
        if (cf == "" || cm == "" || cl == "")
            lblDisplay.Text = InvalidMessage;
        else if (ff == "" || fm == "" || fl == "")
            lblDisplay.Text = InvalidMessage;
        else if (mf == "" || mm == "" || ml == "")
            lblDisplay.Text = InvalidMessage;
        else
           lblDisplay.Text = "Submitted Successfully";
    }
}